//
//  RemoteBinaryPackage.h
//  RemoteBinaryPackage
//
//  Created by 蔡志文 on 2022/4/25.
//

#import <Foundation/Foundation.h>

//! Project version number for RemoteBinaryPackage.
FOUNDATION_EXPORT double RemoteBinaryPackageVersionNumber;

//! Project version string for RemoteBinaryPackage.
FOUNDATION_EXPORT const unsigned char RemoteBinaryPackageVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <RemoteBinaryPackage/PublicHeader.h>


